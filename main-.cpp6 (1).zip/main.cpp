/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

class Time
{
    private:
      int seconds;
      int hh,mm,ss;
    public:
      void getTime(void);
      void convertIntoSeconds(void);
      void displayTime(void);
};

void Time::getTime(void)
{
    cout << "Enter time:";
    cout << "Hours? ";      cin >> hh;
    cout <<"Minutes? ";     cin >> mm;
    cout <<"Seconds? ";     cin >> ss;
}

void Time::convertIntoSeconds(void)
{
    seconds = hh*3600 + mm*60 + ss;
}

void Time::displayTime(void)
{
    cout<<"The time is = ";
    cout<<"Time in total seconds: " << seconds;
}

int main()
{
    Time T; //creating objects
    
    T .getTime();
    T .convertIntoSeconds();
    T .displayTime();
    
    return 0;
}
