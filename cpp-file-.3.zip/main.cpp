#include <iostream>
using namespace std;

int main()
{
    int a1,a2;
    cout<<"Enter your age:";
    cin>>a1;
    cout<<"Enter your brother's age:";
    cin>>a2;
    if(a1>a2)
    cout<<"you are elder";
    else if(a2>a1)
    cout<<"you are younger";
    else
    cout<<"Both of you are of same age";
}
    

